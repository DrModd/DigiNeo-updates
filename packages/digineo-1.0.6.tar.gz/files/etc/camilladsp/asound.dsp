# Режим обработки: плееры, пишущие в "default", идут через ALSA Loopback в CamillaDSP.
defaults.pcm.rate_converter "samplerate_best"
pcm.!default {
    type plug
    slave {
        pcm "hw:CARD=Loopback,DEV=0,SUBDEV=0"
        format S32_LE
        rate 192000
        channels 2
    }
}
ctl.!default {
    type hw
    card Out
}
