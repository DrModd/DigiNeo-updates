#!/bin/bash

LIST=`systemctl --state=running | grep \
    -e networkaudiod \
    -e roonbridge \
    -e raat \
    -e mpd \
    -e upmpdcli \
    -e aplayer \
    -e aprenderer \
    -e squeeze2upnp \
    -e nqptp \
    -e shairport-sync \
    -e squeezelite \
    -e scream \
    -e raspotify \
    -e go-librespot \
    -e tidalconnect \
    -e qobuz-connect \
    | awk '{print $1}'`

for L in $LIST
do
    systemctl stop $L
    systemctl disable $L
done


