<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#101113" media="(prefers-color-scheme: dark)">
    <meta name="theme-color" content="#eef0f2" media="(prefers-color-scheme: light)">
    <title>DigiNeo</title>
    <link rel="icon" href="favicon.svg" type="image/svg+xml">
    <link rel="icon" href="favicon.ico" sizes="any">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="stylesheet" href="assets/css/digifox.css?v=<?php echo VERSION; ?>">
</head>
<body>
<main class="wrap">

    <header class="head">
        <div class="brand">DIGINEO</div>
        <div class="host" id="host"></div>
        <span class="dot" id="dot" title=""></span>
        <button class="icon-btn" id="menu-btn" aria-label="Меню">
            <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </button>
    </header>

    <section class="display">
        <div class="cap" data-t="source">ИСТОЧНИК</div>
        <div class="source" id="source">—</div>
        <div class="track" id="track" hidden>
            <img class="cover" id="t-cover" alt="" hidden>
            <div class="grow">
                <div class="title" id="t-title"></div>
                <div class="artist" id="t-artist"></div>
            </div>
        </div>
        <div class="prog" id="prog" hidden>
            <div class="bar"><i id="prog-fill"></i></div>
            <div class="times"><span id="prog-pos"></span><span id="prog-dur"></span></div>
        </div>
        <div class="rate-row">
            <span class="rate" id="rate">&nbsp;</span>
            <span class="cap" id="mode-cap"></span>
        </div>
    </section>

    <div class="status" id="status"></div>

    <section class="panel">
    <div class="power-row" id="power-row">
        <div class="grow">
            <div class="cap" data-t="amp">УСИЛИТЕЛЬ DIGID D1</div>
            <div class="power-state" id="power-state">—</div>
        </div>
        <button class="hifi power" id="power-btn" data-t="power">POWER</button>
    </div>

    <div class="volume">
        <div class="vol-head">
            <div class="grow">
                <div class="cap" data-t="volume">ГРОМКОСТЬ УСИЛИТЕЛЯ</div>
                <div class="vol-num"><span id="vol-num">--</span><span class="unit" id="vol-unit"></span></div>
            </div>
            <button class="hifi mute" id="mute-btn">MUTE</button>
        </div>
        <input type="range" id="vol" min="0" max="100" value="0" disabled aria-label="Громкость">
        <div class="note" id="vol-note"></div>
    </div>
    </section>

    <section class="panel">
        <div class="cap" data-t="mode">РЕЖИМ</div>
        <div class="row2">
            <button class="hifi" id="mode-net" data-t="net">СЕТЬ</button>
            <button class="hifi" id="mode-usb">USB → I2S</button>
            <!-- DigiNeo: вывод сетевых плееров во внешний USB-ЦАП пока не поддержан (кнопка нужна скрипту) -->
            <button class="hifi" id="mode-dac" data-t="dac" hidden>USB-ЦАП</button>
        </div>
        <div class="note" id="mode-note"></div>
    </section>

    <section class="panel">
        <div class="cap" data-t="players">ПЛЕЕРЫ</div>
        <div class="grid" id="players"></div>
        <a class="hifi player-ui" id="player-ui" target="_blank" rel="noopener" hidden></a>
        <a class="hifi player-ui" href="yandex.php">ЯНДЕКС МУЗЫКА</a>
    </section>

    <footer class="foot" id="foot">DigiNeo v<?php echo htmlspecialchars(VERSION); ?></footer>
</main>

<!-- menu -->
<div class="sheet" id="menu" hidden>
    <div class="sheet-box">
        <div class="cap">DIGINEO v<?php echo htmlspecialchars(VERSION); ?></div>
        <a class="menu-item" href="amplifier.php" data-t="m_amp">Усилитель, будильник, таймер</a>
        <a class="menu-item" href="yandex.php">Яндекс Музыка</a>
        <a class="menu-item" href="radio_edit.php" data-t="m_radio">Радиостанции</a>
        <a class="menu-item" href="settings.php" data-t="m_i2s">Настройки I2S</a>
        <button class="menu-item" id="m-update" data-t="m_update">Обновление прошивки</button>
        <a class="menu-item" href="backup.php" id="m-backup" data-t="m_backup">Сохранить настройки в файл</a>
        <button class="menu-item" id="m-restore" data-t="m_restore">Восстановить настройки из файла</button>
        <a class="menu-item" href="diag.php" data-t="m_diag">Диагностика</a>
        <input type="file" id="restore-file" accept=".json,application/json" hidden>
        <button class="menu-item" id="m-reboot" data-t="m_reboot">Перезагрузить Фокс</button>
        <a class="menu-item" href="classic.php" data-t="m_classic">Классический интерфейс PureFox</a>
        <button class="menu-item dim" id="m-close" data-t="close">Закрыть</button>
    </div>
</div>

<!-- confirm -->
<div class="sheet" id="confirm" hidden>
    <div class="sheet-box">
        <div class="confirm-text" id="confirm-text"></div>
        <div class="row2">
            <button class="hifi" id="confirm-no" data-t="cancel">ОТМЕНА</button>
            <button class="hifi on" id="confirm-yes">OK</button>
        </div>
    </div>
</div>

<!-- update log -->
<div class="sheet" id="update" hidden>
    <div class="sheet-box wide">
        <div class="cap" data-t="m_update">ОБНОВЛЕНИЕ ПРОШИВКИ</div>
        <pre class="log" id="update-log"></pre>
        <button class="hifi" id="update-close" data-t="close">ЗАКРЫТЬ</button>
    </div>
</div>

<script src="assets/js/digifox.js?v=<?php echo VERSION; ?>"></script>
</body>
</html>
