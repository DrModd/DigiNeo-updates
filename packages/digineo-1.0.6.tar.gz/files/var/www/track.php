<?php
// track.php — текущий трек для приложения Fox Remote и усилителя DigiD D1.
//   GET          -> {"source":"qobuz","artist":"...","title":"...","album":"...",
//                    "cover":"https://..."|"", "dur":245000, "pos":61000, "play":true} ({} — нет данных)
//                   dur/pos — мс; dur 0 — длительность неизвестна (радио)
//   GET ?prog=1  -> для усилителя: "позиция_с длительность_с 1|0" (пусто — нет трека)
//   GET ?amp=1   -> одна строка для экрана усилителя: "исполнитель\tназвание" в однобайтовой
//                   кодировке шрифта усилителя (ASCII + кириллица 0x80..0xBF), пусто — нет трека
// Источники: /tmp/nowplaying и /tmp/np_prog (пишет pfmeta для Qobuz, Spotify, AirPlay, Roon), MPD и
// веб-радио APlayer (запрос здесь: станция и что в эфире). Обложки и длительности, которых плеер не дал, ищутся в iTunes (pfmeta art).
// Положить на Фокс в /var/www/track.php.

$np_file = '/tmp/nowplaying';

function active_service() {
    $j = @json_decode((string)@file_get_contents('/tmp/system_status.json'), true);
    $s = is_array($j) && isset($j['active_service']) ? (string)$j['active_service'] : '';
    // DigiNeo: плеер выбирают handle_service.php и pfctl (/tmp/active_service)
    if ($s === '') $s = trim((string)@file_get_contents('/tmp/active_service'));
    return $s;
}

// Яндекс Музыка (ymusicd): обложку трека из очереди MPD кладут yandex.php и ymusicd в /tmp/ymusic/<id>
function ym_cover($file) {
    if (!preg_match('#^http://127\.0\.0\.1:\d+/track/(\d+)#', $file, $m)) return '';
    return trim((string)@file_get_contents('/tmp/ymusic/' . $m[1]));
}

function mpd_track() {
    $s = @fsockopen('127.0.0.1', 6600, $en, $es, 1.0);
    if (!$s) return null;
    stream_set_timeout($s, 1);
    fgets($s);                                         // OK MPD x.y.z
    fwrite($s, "status\ncurrentsong\nclose\n");
    $kv = [];
    while (($l = fgets($s)) !== false) {
        $l = rtrim($l, "\n");
        if ($l === 'OK') continue;
        $p = strpos($l, ': ');
        if ($p !== false && !isset($kv[substr($l, 0, $p)])) $kv[substr($l, 0, $p)] = substr($l, $p + 2);
    }
    fclose($s);
    $state = $kv['state'] ?? '';
    if ($state !== 'play' && $state !== 'pause') return null;
    $title  = $kv['Title'] ?? '';
    $artist = $kv['Artist'] ?? ($kv['Name'] ?? '');     // радио: Name — станция, Title — что играет
    if ($title === '' && isset($kv['file'])) $title = preg_replace('/\.[^.\/]*$/', '', basename($kv['file']));
    $dur = (int)round(1000 * (float)($kv['duration'] ?? ($kv['Time'] ?? 0)));
    return ['source' => 'mpd', 'artist' => $artist, 'title' => $title, 'album' => $kv['Album'] ?? '',
            'cover' => ym_cover($kv['file'] ?? ''), 'dur' => $dur, 'pos' => (int)round(1000 * (float)($kv['elapsed'] ?? 0)),
            'play' => $state === 'play', 'radio' => $dur === 0];
}

// веб-радио APlayer: станция — как исполнитель, то, что сейчас в эфире (ICY) — как название
function aplayer_track() {
    $ctx = stream_context_create(['http' => ['timeout' => 1.5]]);
    $j = @json_decode((string)@file_get_contents('http://127.0.0.1:7778/?State', false, $ctx), true);
    if (!is_array($j) || empty($j['Playing'])) return null;
    $station = trim((string)($j['PlayingName'] ?? ''));
    $station = preg_replace('/\.rad$/i', '', $station);
    $station = trim(preg_replace('/\s*\((?=[^)]*(kbps|aac|flac|mp3|ogg|\d+k\b))[^)]*\)/i', '', $station));
    // что в эфире: ?GetRadio (APlayer обновляет название песни по этому запросу —
    // так делает и его веб-страница раз в 10 с); в ?State оно может быть старым
    $r = @json_decode((string)@file_get_contents('http://127.0.0.1:7778/?GetRadio', false, $ctx), true);
    $now = trim((string)(is_array($r) && isset($r['RadioTitle']) ? $r['RadioTitle'] : ($j['RadioTitle'] ?? '')));
    if ($station === '' && $now === '') return null;
    aplayer_remember((int)($j['Album'] ?? -1), (string)($j['PlayingName'] ?? ''));
    return ['source' => 'aplayer', 'artist' => $station, 'title' => $now !== '' ? $now : $station,
            'album' => '', 'cover' => '', 'dur' => 0, 'pos' => 0, 'play' => true, 'radio' => true];
}

// запомнить станцию, выбранную где угодно (страница APlayer, приложение) — для radio-resume;
// пишется на флеш только при смене станции
function aplayer_remember($album, $name) {
    $name = preg_replace('/\.rad$/i', '', trim($name));
    if ($album < 0 || $name === '') return;
    $f = '/etc/digifox/radio_last';
    $old = @file($f, FILE_IGNORE_NEW_LINES);
    if ($old && ($old[1] ?? '') === $name) return;
    $ctx = stream_context_create(['http' => ['timeout' => 2]]);
    $al = @json_decode((string)@file_get_contents('http://127.0.0.1:7778/?GetAlbums', false, $ctx), true);
    $sec = $al['Albums'][$album] ?? '';
    $sec = trim(preg_replace('/\s*\[[^\]]*\]\s*$/', '', (string)$sec));
    if ($sec === '') return;
    @mkdir('/etc/digifox', 0755, true);
    @file_put_contents("$f.tmp", "$sec\n$name\n") && @rename("$f.tmp", $f);
}

function current_track($np_file) {
    $svc = active_service();
    if ($svc === 'mpd') return mpd_track();
    if ($svc === 'aplayer') return aplayer_track();
    $l = @file($np_file, FILE_IGNORE_NEW_LINES);
    // DigiNeo: Qobuz без нативного Connect идёт через UPnP (upmpdcli -> MPD)
    if ((!$l || count($l) < 3) && $svc === 'qobuz') return mpd_track();
    if (!$l || count($l) < 3) return null;
    if ($svc !== '' && $l[0] !== $svc) return null;    // устаревшее: плеер уже другой
    $t = ['source' => $l[0], 'artist' => $l[1], 'title' => $l[2], 'album' => $l[3] ?? '',
          'cover' => $l[4] ?? '', 'dur' => (int)($l[5] ?? 0), 'pos' => 0, 'play' => true, 'radio' => false];
    // позиция: "мс время_с play|pause" — где трек был в момент time; старше трека — не считается
    $p = preg_split('/\s+/', trim((string)@file_get_contents('/tmp/np_prog')));
    if (count($p) >= 3 && @filemtime('/tmp/np_prog') >= @filemtime($np_file) - 1) {
        $t['play'] = $p[2] === 'play';
        $t['pos'] = max(0, (int)$p[0] + ($t['play'] ? (time() - (int)$p[1]) * 1000 : 0));
    } else {
        $t['pos'] = max(0, (time() - (int)@filemtime($np_file)) * 1000);
    }
    return $t;
}

require_once __DIR__ . '/amp_text.php';           // amp_encode()

// обложка и длительность, которых плеер не дал: iTunes по исполнителю и названию (в фоне,
// результат — в /tmp/np_art: ключ, обложка, мс; запрос — /tmp/np_art.req)
function fill_art(&$t) {
    if (!$t || $t['title'] === '' || ($t['cover'] !== '' && ($t['dur'] > 0 || $t['radio']))) return;
    $key = md5($t['artist'] . "\n" . $t['title']);
    $a = @file('/tmp/np_art', FILE_IGNORE_NEW_LINES);
    if ($a && $a[0] === $key) {
        if ($t['cover'] === '' && ($a[1] ?? '') !== '') $t['cover'] = $a[1];
        // длительность из поиска — только когда плеер её не знает (Qobuz); у радио её нет
        if ($t['dur'] <= 0 && !$t['radio'] && (int)($a[2] ?? 0) > 0) $t['dur'] = (int)$a[2];
        return;
    }
    if (trim((string)@file_get_contents('/tmp/np_art.req')) === $key) return;   // уже ищется
    @file_put_contents('/tmp/np_art.req', $key);
    // веб-радио: «исполнитель» — это станция, а в названии уже «Исполнитель - Песня»
    $term = ($t['source'] ?? '') === 'aplayer' ? $t['title'] : trim($t['artist'] . ' ' . $t['title']);
    $url = 'https://itunes.apple.com/search?media=music&entity=song&limit=1&term=' . rawurlencode($term);
    exec('/usr/bin/pfmeta art ' . escapeshellarg($key) . ' ' . escapeshellarg($url) . ' >/dev/null 2>&1 &');
}

$t = current_track($np_file);
// обложка, отданная самим Фоксом (/np_cover.jpg — Roon): полный адрес для приложения
if ($t && isset($t['cover'][0]) && $t['cover'][0] === '/')
    $t['cover'] = 'http://' . ($_SERVER['HTTP_HOST'] ?? '127.0.0.1') . $t['cover'];
if ($t) {
    fill_art($t);
    if ($t['dur'] > 0 && $t['pos'] > $t['dur']) $t['pos'] = $t['dur'];
}

if (isset($_GET['prog'])) {
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    if ($t && $t['title'] !== '' && $t['dur'] > 0)
        echo intdiv($t['pos'], 1000) . ' ' . intdiv($t['dur'], 1000) . ' ' . ($t['play'] ? 1 : 0);
    exit;
}

if (isset($_GET['amp'])) {
    header('Content-Type: text/plain; charset=x-user-defined');
    header('Cache-Control: no-store');
    if ($t && ($t['title'] !== '' || $t['artist'] !== '')) echo amp_encode($t['artist'], 60) . "\t" . amp_encode($t['title'], 100);
    exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
echo json_encode($t ?: new stdClass(), JSON_UNESCAPED_UNICODE);
