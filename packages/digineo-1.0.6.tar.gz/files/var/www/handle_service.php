<?php
// NEO3-порт handle_service.php: переключение плеера через systemd (php-fpm у Pure работает под root).
require_once 'audio_transition.php';
header('Content-Type: application/json; charset=utf-8');

$units = [
    'raat'       => ['roonbridge'],
    'mpd'        => ['mpd'],
    'aprenderer' => ['aprenderer'],
    'aplayer'    => ['aplayer'],
    'apscream'   => ['scream'],
    'shairport'  => ['nqptp', 'shairport-sync'],
    'lms'        => ['squeezelite'],
    'spotify'    => ['raspotify'],
    'tidal'      => ['tidalconnect'],
    'naa'        => ['networkaudiod'],
    'qobuz'      => ['mpd', 'upmpdcli'],
];

// DigiNeo 1.0.6: Spotify Connect — go-librespot (если установлен), иначе raspotify
if (is_executable('/usr/local/bin/go-librespot')) $units['spotify'] = ['go-librespot'];

// Нативный Qobuz Connect, если бинарник снят с Фокса и установлен (/opt/qobuz-connect).
// Иначе остаётся UPnP (upmpdcli). Переключается автоматически, без пересборки образа.
if (is_executable('/opt/qobuz-connect/qobuz-connect')
    && trim((string) shell_exec('systemctl list-unit-files qobuz-connect.service 2>/dev/null')) !== '') {
    $units['qobuz'] = ['qobuz-connect'];
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'POST only']); exit;
}
$p = $_POST['service'] ?? '';
if (!isset($units[$p])) {
    echo json_encode(['status' => 'error', 'message' => "Invalid player: $p"]); exit;
}

$lock = acquireAudioTransitionLock();
if (!$lock) { echo json_encode(['status' => 'error', 'message' => 'Audio transition already in progress']); exit; }

try {
    @unlink('/tmp/combined_status_cache');
    if (file_exists('/etc/usb_to_i2s.state')) {
        shell_exec('/opt/usb_unlock.sh 2>&1');
    }
    if (is_executable('/opt/scripts/kill-disable.sh')) {
        shell_exec('/opt/scripts/kill-disable.sh 2>/dev/null');
    }
    @unlink('/tmp/nowplaying'); @unlink('/tmp/np_prog');

    $list = implode(' ', array_map('escapeshellarg', $units[$p]));
    shell_exec("systemctl start $list 2>&1");

    @file_put_contents('/tmp/active_service', $p);
    @file_put_contents('/etc/output', 'I2S');

    $primary = end($units[$p]);
    $active  = trim((string) shell_exec('systemctl is-active ' . escapeshellarg($primary) . ' 2>/dev/null'));
    $ok = ($active === 'active');

    echo json_encode([
        'status'    => $ok ? 'success' : 'error',
        'message'   => $ok ? "Switched to $p" : "Failed to start $p ($active)",
        'confirmed' => $ok,
    ]);
} finally {
    releaseAudioTransitionLock($lock);
}
