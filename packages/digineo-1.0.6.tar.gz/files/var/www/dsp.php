<?php
// dsp.php — обработка звука CamillaDSP (обёртка над /usr/local/bin/digineo-dsp)
//   GET ?action=status ; POST action=on|off|preset (preset=flat|room|xover)|install
require_once 'config.php';
define('DSP_BIN', getenv('DIGINEO_DSP') ?: '/usr/local/bin/digineo-dsp');
function reply($d, $code = 200) {
    http_response_code($code); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
    echo json_encode($d, JSON_UNESCAPED_UNICODE); exit;
}
function dsp($args) {
    $p = @proc_open(array_merge([DSP_BIN], $args), [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
    if (!is_resource($p)) return [127, []];
    $o = stream_get_contents($pipes[1]); fclose($pipes[1]); fclose($pipes[2]);
    $rc = proc_close($p); $kv = [];
    foreach (explode("\n", $o) as $l) { $i = strpos($l, '='); if ($i > 0) $kv[substr($l, 0, $i)] = trim(substr($l, $i + 1)); }
    return [$rc, $kv, trim($o)];
}
$a = $_REQUEST['action'] ?? '';
if ($a !== '') {
    if ($a === 'status') { list(, $kv) = dsp(['status']); reply($kv ?: ['error' => 'no_tool'], $kv ? 200 : 500); }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') reply(['error' => 'post_required'], 405);
    if ($a === 'on' || $a === 'off') { list($rc, , $t) = dsp([$a]); reply(['ok' => $rc === 0, 'msg' => $t], $rc ? 409 : 200); }
    if ($a === 'preset') { list($rc, , $t) = dsp(['preset', (string)($_POST['preset'] ?? '')]); reply(['ok' => $rc === 0, 'msg' => $t], $rc ? 400 : 200); }
    if ($a === 'install') {
        exec('systemctl start --no-block digineo-dsp-setup.service 2>&1', $o, $rc);
        reply(['ok' => $rc === 0]);
    }
    reply(['error' => 'unknown_action'], 400);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#101113" media="(prefers-color-scheme: dark)">
    <meta name="theme-color" content="#eef0f2" media="(prefers-color-scheme: light)">
    <title>DigiNeo — Обработка звука</title>
    <link rel="icon" href="favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="assets/css/digifox.css?v=<?php echo VERSION; ?>">
    <style>
        .pre { width: 100%; text-align: left; min-height: 56px; margin-top: 8px; display: flex; flex-direction: column; gap: 2px; }
        .pre .s { font-size: 12px; color: var(--dim); }
        .pre.on { border-color: var(--live); }
    </style>
</head>
<body>
<main class="wrap">
    <header class="head">
        <a class="back" href="amplifier.php" aria-label="Назад">
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </a>
        <div class="brand">Обработка звука</div>
        <span class="dot" id="dot"></span>
    </header>
    <div class="status" id="status"></div>

    <section class="panel">
        <div class="set-head"><div class="cap grow">CAMILLADSP</div><div class="set-val" id="v-state">…</div></div>
        <div class="hint" id="v-hint"></div>
        <div class="row2" style="margin-top:12px">
            <button class="hifi" id="b-on" disabled>ВКЛЮЧИТЬ</button>
            <button class="hifi" id="b-off" disabled>ВЫКЛЮЧИТЬ</button>
        </div>
        <button class="hifi wide" id="b-inst" style="margin-top:10px" hidden>УСТАНОВИТЬ CAMILLADSP</button>
    </section>

    <section class="panel" id="p-pre" hidden>
        <div class="cap">КОНФИГУРАЦИЯ</div>
        <button class="hifi pre" data-p="flat"><span>Без коррекции</span><span class="s">Только запас по уровню −1 дБ</span></button>
        <button class="hifi pre" data-p="room"><span>Коррекция помещения</span><span class="s">Биквады/FIR из REW — подставьте свои в редакторе</span></button>
        <button class="hifi pre" data-p="xover"><span>Кроссовер 2-way</span><span class="s">LR24, 2,5 кГц, выход 2→4 (нужна 4-канальная карта)</span></button>
        <a class="hifi wide" id="a-gui" href="#" target="_blank" rel="noopener" style="margin-top:12px;display:block;text-align:center;text-decoration:none;line-height:44px" hidden>ОТКРЫТЬ РЕДАКТОР ФИЛЬТРОВ</a>
    </section>

    <section class="panel">
        <div class="hint">При включении плееры, пишущие в системное устройство «default», идут через CamillaDSP на частоте 192 кГц и не битперфект. Roon Bridge и другие плееры с выбором карты вручную выбирайте устройство «Loopback». Выключено — звук идёт на I2S напрямую. После переключения перезапустите воспроизведение.</div>
    </section>
</main>
<script>
(function () {
    function $(i) { return document.getElementById(i); }
    var st = {}, busy = false, tmr = null, poll = null;
    function status(t, spin) {
        clearTimeout(tmr); var s = $('status'); s.className = 'status' + (spin ? ' busy' : ''); s.textContent = t || '';
        if (t && !spin) tmr = setTimeout(function () { s.textContent = ''; }, 6000);
    }
    function api(action, body) {
        var opt = body ? { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=' + action + Object.keys(body).map(function (k) { return '&' + k + '=' + encodeURIComponent(body[k]); }).join('') } : { cache: 'no-store' };
        return fetch('dsp.php?' + (body ? '' : 'action=' + action), opt).then(function (r) {
            return r.json().then(function (j) { if (!r.ok) { var e = new Error(j.msg || j.error || ('HTTP ' + r.status)); throw e; } return j; });
        });
    }
    function render() {
        var inst = st.installed === '1', on = st.enabled === '1', run = st.setup === 'active' || st.setup === 'activating';
        $('dot').className = 'dot' + (on && st.active === 'active' ? ' on' : '');
        $('v-state').textContent = !inst ? (run ? 'устанавливается…' : 'не установлен') : (on ? 'включено' : 'выключено');
        $('v-hint').textContent = !inst ? (run ? 'Скачивание и установка, несколько минут. Журнал: /var/log/digineo-dsp-setup.log' : 'Нужен интернет на плате. Установка скачает CamillaDSP и редактор фильтров.')
            : (on ? 'Звук идёт через фильтры.' : 'Битперфект: звук идёт на I2S напрямую.');
        $('b-on').disabled = busy || !inst || on; $('b-off').disabled = busy || !inst || !on;
        $('b-inst').hidden = inst; $('b-inst').disabled = busy || run;
        $('p-pre').hidden = !inst;
        Array.prototype.forEach.call(document.querySelectorAll('.pre'), function (b) { b.className = 'hifi pre' + (b.getAttribute('data-p') === st.preset ? ' on' : ''); });
        $('a-gui').hidden = st.gui !== '1'; $('a-gui').href = 'http://' + location.hostname + ':5000/';
    }
    function load() { return api('status').then(function (j) { st = j; render(); }).catch(function () { $('v-state').textContent = 'нет связи'; }); }
    function act(action, body, msg) {
        if (busy) return; busy = true; render(); status(msg, true);
        api(action, body || {}).then(function () { status('Готово'); }).catch(function (e) { status('Ошибка: ' + e.message); })
            .then(function () { busy = false; return load(); });
    }
    $('b-on').addEventListener('click', function () { act('on', {}, 'Включаю…'); });
    $('b-off').addEventListener('click', function () { act('off', {}, 'Выключаю…'); });
    $('b-inst').addEventListener('click', function () { act('install', {}, 'Запускаю установку…'); clearInterval(poll); poll = setInterval(load, 5000); });
    Array.prototype.forEach.call(document.querySelectorAll('.pre'), function (b) {
        b.addEventListener('click', function () { act('preset', { preset: b.getAttribute('data-p') }, 'Применяю…'); });
    });
    load().then(function () { if (st.setup === 'active' || st.setup === 'activating') poll = setInterval(load, 5000); });
})();
</script>
</body>
</html>
