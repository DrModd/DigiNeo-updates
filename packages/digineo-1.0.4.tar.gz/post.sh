#!/bin/bash
# 1.0.4: улучшения DigiFox (октябрь–ноябрь 2026) на DigiNeo:
#   pfctl как в DigiFox (трек и позиция через track.php — кириллица на экране усилителя,
#   IP, веб-радио и Яндекс Музыка в меню усилителя, кнопки плеера с пульта, будильник и
#   таймер сна, USB -> I2S с усилителя, журнал событий усилителя, @UPD), прошивка усилителя
#   1.14 и digifox-ampflash, названия треков Qobuz Connect и AirPlay, стрелочные индикаторы,
#   новый uac2_router (DoP, @HUSH) — собирается на плате (digineo-build.service).
set -e
D=/opt/digineo
chmod 0755 $D/bin/*

# --- общие данные DigiFox: прошивка усилителя 1.14, таблицы пиньинь для экрана ---
mkdir -p /usr/share/digifox
cp -p $D/share/digifox/* /usr/share/digifox/

# --- команды в /usr/bin (ссылки на /opt/digineo/bin: следующие пакеты обновят их сами) ---
for f in digifox-ampflash digifox-alarm; do
    ln -sfn $D/bin/$f /usr/bin/$f
done

# --- pfctl: новый, со старым — в /usr/bin/pfctl.pre-1.0.4 ---
sh -n $D/bin/pfctl
[ -f /usr/bin/pfctl.pre-1.0.4 ] || cp -p /usr/bin/pfctl /usr/bin/pfctl.pre-1.0.4
cp $D/bin/pfctl /usr/bin/.pfctl.new && chmod 0755 /usr/bin/.pfctl.new && mv /usr/bin/.pfctl.new /usr/bin/pfctl

# --- AirPlay: канал метаданных shairport-sync -> pfmeta airplay (название трека) ---
SP=/usr/local/etc/shairport-sync.conf
if [ -f "$SP" ] && ! grep -q '// digineo-meta' "$SP"; then
    [ -f "$SP.pre-1.0.4" ] || cp -p "$SP" "$SP.pre-1.0.4"
    sed -i -e 's#^//[[:space:]]*enabled = "yes"; // set this to yes to get Shairport Sync to solicit metadata.*#\tenabled = "yes"; // digineo-meta#' \
           -e 's#^//[[:space:]]*pipe_name = "/tmp/shairport-sync-metadata";#\tpipe_name = "/tmp/shairport-sync-metadata";#' "$SP"
    grep -q '// digineo-meta' "$SP" || echo "shairport-sync.conf: строка metadata не найдена, AirPlay без названий"
fi

# --- systemd: Qobuz -> pfmeta, APlayer продолжает радио, сборка на плате ---
systemctl daemon-reload
systemctl enable digineo-build.service >/dev/null 2>&1 || true
systemctl start --no-block digineo-build.service || true
systemctl restart --no-block pfctl.service 2>/dev/null || true
echo "Названия Qobuz и AirPlay — после перезапуска этих плееров (или перезагрузки)."
echo "Сборка pfrate/uac2_router/digilvl и установка stm32flash идут в фоне: /var/log/digineo-build.log"
