#!/bin/bash
# 1.0.5 (накопительный: всё из 1.0.1–1.0.4 — каталог обновлений ставит только последнюю версию)
#   1.0.5: Roon — название, обложка, позиция и кнопки (расширение Roon digineo-roon);
#          нативный Qobuz Connect — кнопки плеера с пульта (новая libassert_hook.so с qbz_ctl).
#   1.0.4: улучшения DigiFox (pfctl, track.php, радио, будильник, прошивка усилителя 1.14,
#          индикаторы, uac2_router; C-части собирает digineo-build.service).
#   1.0.3: CamillaDSP (пункт в меню, фоновая установка).
#   1.0.1: avahi ждёт сеть.
set -e
D=/opt/digineo
chmod 0755 $D/bin/* /usr/local/bin/digineo-dsp /usr/local/bin/digineo-dsp-setup
chmod 0755 /opt/qobuz-connect/rt/libassert_hook.so

# --- 1.0.3: CamillaDSP — свои настройки и конфигурации пользователя не трогаем ---
mkdir -p /etc/camilladsp/configs
[ -f /etc/camilladsp/dsp.conf ] || cp $D/defaults/camilladsp/dsp.conf /etc/camilladsp/dsp.conf
for f in $D/defaults/camilladsp/configs/*.yml; do
    [ -f "/etc/camilladsp/configs/$(basename "$f")" ] || cp "$f" /etc/camilladsp/configs/
done
A=/var/www/amplifier.php
if [ -f "$A" ] && ! grep -q 'href="dsp.php"' "$A"; then
    [ -f "$A.pre-1.0.3" ] || cp -p "$A" "$A.pre-1.0.3"
    python3 - "$A" <<'PY'
import sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()
row = ('        <div class="switch-row" style="margin-top:12px">\n'
       '            <div class="grow"><div class="t">Обработка звука</div><div class="d">CamillaDSP: коррекция помещения, кроссовер</div></div>\n'
       '            <a class="hifi" href="dsp.php" style="width:72px;flex:none;text-align:center;text-decoration:none;display:flex;align-items:center;justify-content:center">→</a>\n'
       '        </div>\n')
for k in ('href="update.php"', 'href="wifi.php"'):
    i = s.find(k)
    j = s.find('        </div>\n', i) if i >= 0 else -1
    if j >= 0:
        j += len('        </div>\n'); s = s[:j] + row + s[j:]
        open(p, 'w', encoding='utf-8').write(s); sys.exit(0)
sys.exit(1)
PY
fi

# --- 1.0.4: данные DigiFox (прошивка усилителя 1.14, пиньинь), команды, pfctl ---
mkdir -p /usr/share/digifox
cp -p $D/share/digifox/* /usr/share/digifox/
for f in digifox-ampflash digifox-alarm; do ln -sfn $D/bin/$f /usr/bin/$f; done
sh -n $D/bin/pfctl
[ -f /usr/bin/pfctl.pre-1.0.4 ] || cp -p /usr/bin/pfctl /usr/bin/pfctl.pre-1.0.4
cp $D/bin/pfctl /usr/bin/.pfctl.new && chmod 0755 /usr/bin/.pfctl.new && mv /usr/bin/.pfctl.new /usr/bin/pfctl
# AirPlay: канал метаданных shairport-sync -> pfmeta airplay
SP=/usr/local/etc/shairport-sync.conf
if [ -f "$SP" ] && ! grep -q '// digineo-meta' "$SP"; then
    [ -f "$SP.pre-1.0.4" ] || cp -p "$SP" "$SP.pre-1.0.4"
    sed -i -e 's#^//[[:space:]]*enabled = "yes"; // set this to yes to get Shairport Sync to solicit metadata.*#\tenabled = "yes"; // digineo-meta#' \
           -e 's#^//[[:space:]]*pipe_name = "/tmp/shairport-sync-metadata";#\tpipe_name = "/tmp/shairport-sync-metadata";#' "$SP"
    grep -q '// digineo-meta' "$SP" || echo "shairport-sync.conf: строка metadata не найдена, AirPlay без названий"
fi

# --- 1.0.5: Roon (расширение), Qobuz (кнопки) ---
python3 -c 'import sys; sys.path.insert(0, "/opt/digineo/py"); import roonapi, websocket' \
    || { echo "python3: не загружается roonapi/websocket"; exit 1; }
mkdir -p /etc/digineo

# --- systemd ---
systemctl daemon-reload
systemctl enable digineo-build.service digineo-roon.service >/dev/null 2>&1 || true
systemctl start --no-block digineo-build.service || true
systemctl restart --no-block digineo-roon.service || true
systemctl restart --no-block pfctl.service 2>/dev/null || true
[ -x /usr/local/bin/camilladsp ] || systemctl start --no-block digineo-dsp-setup.service 2>/dev/null || true

echo "Roon: включите расширение «DigiNeo» в Roon -> Настройки -> Расширения (один раз)."
echo "Названия Qobuz и AirPlay и кнопки Qobuz — после перезапуска этих плееров (или перезагрузки)."
echo "Сборка pfrate/uac2_router/digilvl и установка stm32flash идут в фоне: /var/log/digineo-build.log"
