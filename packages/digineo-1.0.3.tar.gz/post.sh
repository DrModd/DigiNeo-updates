#!/bin/bash
# 1.0.3: CamillaDSP — пункт в меню и фоновая установка (если ещё не стоит)
set -e
chmod +x /usr/local/bin/digineo-dsp /usr/local/bin/digineo-dsp-setup
A=/var/www/amplifier.php
if [ -f "$A" ] && ! grep -q 'href="dsp.php"' "$A"; then
    cp -p "$A" "$A.pre-1.0.3"
    python3 - "$A" <<'PY'
import sys
p = sys.argv[1]; s = open(p, encoding='utf-8').read()
row = ('        <div class="switch-row" style="margin-top:12px">\n'
       '            <div class="grow"><div class="t">Обработка звука</div><div class="d">CamillaDSP: коррекция помещения, кроссовер</div></div>\n'
       '            <a class="hifi" href="dsp.php" style="width:72px;flex:none;text-align:center;text-decoration:none;display:flex;align-items:center;justify-content:center">→</a>\n'
       '        </div>\n')
k = 'href="update.php"'
i = s.find(k)
j = s.find('        </div>\n', i) if i >= 0 else -1
if j >= 0:
    j += len('        </div>\n'); s = s[:j] + row + s[j:]
else:
    k2 = 'href="wifi.php"'; i = s.find(k2); j = s.find('        </div>\n', i)
    if i < 0 or j < 0: sys.exit(1)
    j += len('        </div>\n'); s = s[:j] + row + s[j:]
open(p, 'w', encoding='utf-8').write(s)
PY
fi
systemctl daemon-reload
[ -x /usr/local/bin/camilladsp ] || systemctl start --no-block digineo-dsp-setup.service
