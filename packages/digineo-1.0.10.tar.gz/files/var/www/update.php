<?php
// update.php — онлайн-обновление DigiNeo из каталога DrModd/DigiNeo-updates.
//   GET  ?action=status   версия на плате, последняя в каталоге (если спросили ?check=1), состояние и журнал (JSON)
//   POST action=install   запустить установку последней версии (фоном, переживает перезапуск служб)
// Всю работу делает /opt/digineo/bin/digineo-update.
require_once 'config.php';
const TOOL = '/opt/digineo/bin/digineo-update';
function reply($d, $code = 200) {
    http_response_code($code); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
    echo json_encode($d, JSON_UNESCAPED_UNICODE); exit;
}
function kv($o) {
    $r = [];
    foreach (explode("\n", $o) as $l) { $i = strpos($l, '='); if ($i > 0) $r[substr($l, 0, $i)] = trim(substr($l, $i + 1)); }
    return $r;
}
function running() {
    return trim((string)shell_exec('systemctl is-active digineo-update-run 2>/dev/null')) === 'active';
}
function status($check) {
    $o = (string)shell_exec(escapeshellarg(TOOL) . ' status 30 2>/dev/null');
    $p = strpos($o, "log<<\n");
    $st = kv($p === false ? $o : substr($o, 0, $p));
    $log = $p === false ? '' : substr($o, $p + 6);
    $r = ['state' => $st['state'] ?? 'idle', 'msg' => $st['msg'] ?? '', 'log' => rtrim($log), 'running' => running()];
    if ($r['running']) $r['state'] = 'running';
    $r['current'] = trim(strtok((string)@file_get_contents('/etc/digifox-release'), "\n")) ?: '—';
    if ($check && !$r['running']) {
        $k = kv((string)shell_exec('timeout 40 ' . escapeshellarg(TOOL) . ' check 2>/dev/null'));
        $r['latest'] = $k['latest'] ?? null; $r['available'] = ($k['available'] ?? '') === '1';
        $r['notes'] = $k['notes'] ?? ''; $r['error'] = $k['error'] ?? '';
    }
    return $r;
}
$a = $_REQUEST['action'] ?? '';
if ($a !== '') {
    if ($a === 'status') reply(status(($_GET['check'] ?? '') === '1'));
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') reply(['error' => 'post_required'], 405);
    if ($a === 'install') {
        if (running()) reply(['error' => 'Обновление уже идёт'], 409);
        // отдельным юнитом: во время обновления перезапускаются службы, веб-запрос не должен его убить
        shell_exec('systemd-run --no-block --unit=digineo-update-run ' . escapeshellarg(TOOL) . ' install >/dev/null 2>&1');
        reply(['started' => true]);
    }
    reply(['error' => 'unknown_action'], 400);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#101113" media="(prefers-color-scheme: dark)">
    <meta name="theme-color" content="#eef0f2" media="(prefers-color-scheme: light)">
    <title>DigiNeo — обновление прошивки</title>
    <link rel="icon" href="favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="assets/css/digifox.css?v=<?php echo VERSION; ?>">
    <style>
        .kv { display: flex; justify-content: space-between; gap: 12px; padding: 6px 0; font-size: 14px; }
        .kv .k { color: var(--dim); }
        pre.log { margin: 10px 0 0; padding: 10px; max-height: 260px; overflow: auto; font-size: 12px; white-space: pre-wrap; word-break: break-word; border-radius: 10px; background: rgba(127,127,127,.12); }
    </style>
</head>
<body>
<main class="wrap">
    <header class="head">
        <a class="back" href="index.php" aria-label="Назад">
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </a>
        <div class="brand">Обновление прошивки</div>
        <span class="dot" id="dot"></span>
    </header>
    <div class="status" id="status"></div>

    <section class="panel">
        <div class="cap">ВЕРСИЯ</div>
        <div class="kv"><span class="k">На плате</span><span id="v-cur">…</span></div>
        <div class="kv"><span class="k">В каталоге</span><span id="v-new">…</span></div>
        <div class="hint" id="v-notes"></div>
        <div class="row2" style="margin-top:12px">
            <button class="hifi" id="b-check">ПРОВЕРИТЬ</button>
            <button class="hifi" id="b-install" disabled>УСТАНОВИТЬ</button>
        </div>
    </section>

    <section class="panel">
        <div class="cap">ЖУРНАЛ</div>
        <pre class="log" id="log">—</pre>
        <div class="hint">Обновление качается с GitHub (DrModd/DigiNeo-updates), нужен интернет на плате. Ставится сразу последняя версия, в ней уже есть всё из прежних. Во время установки службы могут на пару секунд перезапуститься; плату перезагружать нужно, только если об этом сказано в журнале.</div>
    </section>
</main>
<script>
(function () {
    function $(i) { return document.getElementById(i); }
    var st = {}, busy = false, poll = null, tmr = null;
    function status(t, spin) {
        clearTimeout(tmr); var s = $('status'); s.className = 'status' + (spin ? ' busy' : ''); s.textContent = t || '';
        if (t && !spin) tmr = setTimeout(function () { s.textContent = ''; }, 6000);
    }
    function api(action, body, query) {
        var opt = body ? { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'action=' + action } : { cache: 'no-store' };
        return fetch('update.php?' + (body ? '' : 'action=' + action + (query || '')), opt).then(function (r) {
            return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || ('HTTP ' + r.status)); return j; });
        });
    }
    function render() {
        var run = st.state === 'running';
        $('dot').className = 'dot' + (run ? ' on' : '');
        $('v-cur').textContent = st.current || '—';
        $('v-new').textContent = st.error ? 'нет связи' : (st.latest ? st.latest + (st.available ? ' (есть обновление)' : ' (последняя)') : '…');
        $('v-notes').textContent = st.error || (st.available && st.notes ? st.notes : '');
        $('log').textContent = st.log || '—';
        $('b-check').disabled = busy || run;
        $('b-install').disabled = busy || run || !st.available;
        if (run) status('Идёт обновление… ' + (st.msg || ''), true);
        else if (st.state === 'fail') status('Ошибка: ' + st.msg);
        else if (st.state === 'ok' && st.msg) status(st.msg);
    }
    function load(check) {
        return api('status', null, check ? '&check=1' : '').then(function (j) {
            var keep = { latest: st.latest, available: st.available, notes: st.notes, error: st.error };
            st = j; if (!check && j.latest === undefined) for (var k in keep) st[k] = keep[k];
            render();
        }).catch(function () { status('Нет связи с платой (возможно, перезапускаются службы)…', true); });
    }
    function startPoll() {
        clearInterval(poll);
        poll = setInterval(function () { load(false).then(function () { if (st.state !== 'running') { clearInterval(poll); load(true); } }); }, 3000);
    }
    $('b-check').addEventListener('click', function () { busy = true; render(); status('Проверяю каталог…', true); load(true).then(function () { busy = false; render(); if (!st.error) status(''); }); });
    $('b-install').addEventListener('click', function () {
        if (busy) return; busy = true; render(); status('Запускаю…', true);
        api('install', {}).then(function () { busy = false; st.state = 'running'; render(); startPoll(); })
            .catch(function (e) { busy = false; status('Ошибка: ' + e.message); render(); });
    });
    load(true).then(function () { if (st.state === 'running') startPoll(); });
})();
</script>
</body>
</html>
