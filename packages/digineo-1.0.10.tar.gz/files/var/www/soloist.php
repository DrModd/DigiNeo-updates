<?php
// soloist.php — Spotify Soloist (официальный плеер Spotify): ключ разработчика и состояние.
//   GET ?action=status        состояние (JSON)
//   POST action=save key=…    сохранить ключ, фоном скачать Soloist и перезапустить Spotify
//   POST action=clear         убрать ключ — снова go-librespot
// Ключ: /etc/digineo/soloist.key (0600). Скачивание и запуск — /opt/digineo/bin/digineo-soloist.
require_once 'config.php';
const KEYF = '/etc/digineo/soloist.key';
const TOOL = '/opt/digineo/bin/digineo-soloist';
function reply($d, $code = 200) {
    http_response_code($code); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
    echo json_encode($d, JSON_UNESCAPED_UNICODE); exit;
}
function state() {
    $o = (string)shell_exec(escapeshellarg(TOOL) . ' status 2>/dev/null');
    $kv = [];
    foreach (explode("\n", $o) as $l) { $i = strpos($l, '='); if ($i > 0) $kv[substr($l, 0, $i)] = trim(substr($l, $i + 1)); }
    if (preg_match('/soloist\s+([0-9][0-9.]*)/i', $kv['version'] ?? '', $m)) $kv['version'] = $m[1];
    $kv['librespot'] = trim((string)shell_exec('systemctl is-active go-librespot 2>/dev/null')) === 'active';
    return $kv;
}
function restart_spotify() {
    if (trim((string)shell_exec('systemctl is-active go-librespot 2>/dev/null')) === 'active')
        shell_exec('systemctl restart --no-block go-librespot >/dev/null 2>&1');
}
$a = $_REQUEST['action'] ?? '';
if ($a !== '') {
    if ($a === 'status') reply(state());
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') reply(['error' => 'post_required'], 405);
    if ($a === 'save') {
        $k = trim((string)($_POST['key'] ?? ''));
        if ($k === '' || strlen($k) > 512 || !preg_match('/^[A-Za-z0-9._~+\/=-]+$/', $k)) reply(['error' => 'Ключ не похож на ключ Soloist'], 400);
        @mkdir('/etc/digineo', 0755, true);
        $t = KEYF . '.tmp';
        if (@file_put_contents($t, $k . "\n") === false) reply(['error' => 'Не записать ключ'], 500);
        @chmod($t, 0600); @rename($t, KEYF);
        // плеер ≈33 МБ + glibc ≈3 МБ — качаются фоном, потом Spotify перезапускается сам
        shell_exec('systemctl start --no-block digineo-soloist-setup.service >/dev/null 2>&1');
        shell_exec('sync');
        reply(state());
    }
    if ($a === 'clear') {
        @unlink(KEYF); restart_spotify(); shell_exec('sync');
        reply(state());
    }
    reply(['error' => 'unknown_action'], 400);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#101113" media="(prefers-color-scheme: dark)">
    <meta name="theme-color" content="#eef0f2" media="(prefers-color-scheme: light)">
    <title>DigiNeo — Spotify Soloist</title>
    <link rel="icon" href="favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="assets/css/digifox.css?v=<?php echo VERSION; ?>">
    <style>
        .kv { display: flex; justify-content: space-between; gap: 12px; padding: 6px 0; font-size: 14px; }
        .kv .k { color: var(--dim); }
        input.text { width: 100%; box-sizing: border-box; margin-top: 8px; }
    </style>
</head>
<body>
<main class="wrap">
    <header class="head">
        <a class="back" href="amplifier.php" aria-label="Назад">
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </a>
        <div class="brand">Spotify Soloist</div>
        <span class="dot" id="dot"></span>
    </header>
    <div class="status" id="status"></div>

    <section class="panel">
        <div class="cap">СОСТОЯНИЕ</div>
        <div class="kv"><span class="k">Плеер Spotify</span><span id="v-run">…</span></div>
        <div class="kv"><span class="k">Soloist</span><span id="v-ver">…</span></div>
        <div class="kv"><span class="k">Ключ</span><span id="v-key">…</span></div>
        <div class="hint" id="v-hint"></div>
    </section>

    <section class="panel">
        <div class="cap">КЛЮЧ SOLOIST (API KEY)</div>
        <input class="text" type="password" id="key" autocomplete="off" spellcheck="false" aria-label="Ключ Spotify Soloist">
        <div class="row2" style="margin-top:12px">
            <button class="hifi" id="b-save">СОХРАНИТЬ</button>
            <button class="hifi" id="b-clear">УБРАТЬ КЛЮЧ</button>
        </div>
    </section>

    <section class="panel">
        <div class="hint">Spotify отказывает в треках сторонним плеерам на части аккаунтов. С ключом плата играет через официальный плеер Spotify (Soloist), в том числе без потерь. Ключ — один раз: developer.spotify.com → Soloist API Key (нужен Premium). Плеер Spotify запрещает распространять, поэтому плата скачивает его сама (≈35 МБ, пара минут) и обновляет раз в 60 дней. Громкость меняется только усилителем. Без ключа работает прежний плеер (go-librespot). Журнал: /var/log/digineo-soloist.log</div>
    </section>
</main>
<script>
(function () {
    function $(i) { return document.getElementById(i); }
    var st = {}, busy = false, tmr = null, poll = null;
    function status(t, spin) {
        clearTimeout(tmr); var s = $('status'); s.className = 'status' + (spin ? ' busy' : ''); s.textContent = t || '';
        if (t && !spin) tmr = setTimeout(function () { s.textContent = ''; }, 6000);
    }
    function api(action, body) {
        var opt = body ? { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=' + action + Object.keys(body).map(function (k) { return '&' + k + '=' + encodeURIComponent(body[k]); }).join('') } : { cache: 'no-store' };
        return fetch('soloist.php?' + (body ? '' : 'action=' + action), opt).then(function (r) {
            return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || ('HTTP ' + r.status)); return j; });
        });
    }
    function render() {
        var run = st.running === '1', key = st.key === '1', setup = st.setup === '1';
        $('dot').className = 'dot' + (run ? ' on' : '');
        $('v-run').textContent = run ? 'официальный Soloist' : (st.librespot ? 'go-librespot' : 'не запущен');
        $('v-ver').textContent = setup ? 'скачивается…' : (st.player === '1' ? (st.version || 'есть') : 'не скачан');
        $('v-key').textContent = key ? 'введён' : 'нет';
        $('v-hint').textContent = setup ? 'Скачивание и подготовка, 1–3 минуты. После этого Spotify перезапустится сам.'
            : (key && st.player !== '1' ? ('Плеер не скачался. ' + (st.last || 'Нужен интернет на плате.')) : (st.last && !run && key ? st.last : ''));
        $('b-clear').disabled = busy || !key;
        $('b-save').disabled = busy;
    }
    function load() { return api('status').then(function (j) { st = j; render(); }).catch(function () { $('v-run').textContent = 'нет связи'; }); }
    function startPoll() { clearInterval(poll); poll = setInterval(function () { load().then(function () { if (st.setup !== '1') { clearInterval(poll); } }); }, 4000); }
    function act(action, body, msg) {
        if (busy) return; busy = true; render(); status(msg, true);
        return api(action, body || {}).then(function () { status('Готово'); startPoll(); }).catch(function (e) { status('Ошибка: ' + e.message); })
            .then(function () { busy = false; return load(); });
    }
    $('b-save').addEventListener('click', function () {
        var k = $('key').value.trim(); if (!k) { status('Введите ключ'); return; }
        act('save', { key: k }, 'Сохраняю…').then(function () { $('key').value = ''; });
    });
    $('b-clear').addEventListener('click', function () { act('clear', {}, 'Убираю…'); });
    load().then(function () { if (st.setup === '1') startPoll(); });
})();
</script>
</body>
</html>
